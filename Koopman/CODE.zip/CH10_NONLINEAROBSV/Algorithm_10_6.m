Y1=[X1; abs(X1).^2];  %% Data observables g1
Y2=[X2; abs(X2).^2];  %% Shifted Data